FICHIER MODIFIER:
  ** ProductController
    
    ** HTML: home, list et styles.css